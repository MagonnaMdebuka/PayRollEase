

document.addEventListener("DOMContentLoaded", function() {
    const registrationForm = document.getElementById("registrationForm");

    registrationForm.addEventListener("submit", function(event) {
        event.preventDefault();

        // Get form values
        const firstName = document.getElementById("firstName").value.trim();
        const lastName = document.getElementById("lastName").value.trim();
        const email = document.getElementById("email").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const address = document.getElementById("address").value.trim();
        const city = document.getElementById("city").value.trim();
        const state = document.getElementById("state").value.trim();
        const zip = document.getElementById("zip").value.trim();
        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value.trim();
        const confirmPassword = document.getElementById("confirmPassword").value.trim();
        const employeeId = document.getElementById("employeeId").value.trim();
        const department = document.getElementById("department").value.trim();
        const position = document.getElementById("position").value.trim();
        const salary = document.getElementById("salary").value.trim();

        // Simple validation
        if (
            !firstName || !lastName || !email || !phone || !address || !city || !state || !zip ||
            !username || !password || !confirmPassword || !employeeId || !department || !position || !salary
        ) {
            alert("Please fill out all fields.");
            return;
        }

        if (password !== confirmPassword) {
            alert("Passwords do not match.");
            return;
        }

        // Register the user with Firebase Authentication
        createUserWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                // Signed in 
                const user = userCredential.user;
                
                // Save user information to Firestore
                return setDoc(doc(db, "users", user.uid), {
                    firstName,
                    lastName,
                    email,
                    phone,
                    address,
                    city,
                    state,
                    zip,
                    username,
                    employeeId,
                    department,
                    position,
                    salary
                });
            })
            .then(() => {
                alert("Registration successful!");
                registrationForm.reset();
            })
            .catch((error) => {
                console.error("Error registering user: ", error);
                alert("Error registering user: " + error.message);
            });
    });
});
